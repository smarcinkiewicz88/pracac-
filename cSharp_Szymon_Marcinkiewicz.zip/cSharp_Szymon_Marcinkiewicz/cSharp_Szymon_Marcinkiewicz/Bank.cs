﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace cSharp_Szymon_Marcinkiewicz
{
        public class Bank
        {
            private string adres;
            private int ernings;
            private int avgCustomersPerMounth;
            private string menager;
            private int numberOfEmplyers;

            public Bank(string adres, int ernings, int avgCustomersPerMounth, string menager, int numberOfEmplyers)
            {
                this.adres = adres;
                this.ernings = ernings;
                this.avgCustomersPerMounth = avgCustomersPerMounth;
                this.menager = menager;
                this.numberOfEmplyers = numberOfEmplyers;

            }

            public string getAdres()
            {
                return adres;
            }
            public int getErnings()
            {
                return ernings;
            }
            public int getAvgCustomersPerMounth()
            {
                return avgCustomersPerMounth;
            }
            public string getMenager()
            {
                return menager;
            }
            public int getNumberOfEmplyers()
            {
                return numberOfEmplyers;
            }
        }
        }

    

