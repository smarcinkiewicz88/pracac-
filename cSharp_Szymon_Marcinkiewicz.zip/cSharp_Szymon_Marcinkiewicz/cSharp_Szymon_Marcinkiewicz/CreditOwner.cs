﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace cSharp_Szymon_Marcinkiewicz
{

            public class CreditOwner
            {
                private string cOName;
                private string cOSurname;
                private int cOPesel;
                private string cOAdres;
                private int cOPhoneNumber;

                public CreditOwner(string cOName, string cOSurname, int cOPesel, string cOAdres, int cOPhoneNumber)
                {
                    this.cOName = cOName;
                    this.cOSurname = cOSurname;
                    this.cOPesel = cOPesel;
                    this.cOAdres = cOAdres;
                    this.cOPhoneNumber = cOPhoneNumber;
                }
                public string getCOName()
                {
                    return cOName;
                }
                public string getCOSurname()
                {
                    return cOSurname;
                }
                public int getCOPesel()
                {
                    return cOPesel;
                }
                public string getCOAdres()
                {
                    return cOAdres;
                }
                public int getCOPhoneNumber()
                {
                    return cOPhoneNumber;
                }



        }

}

