﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cSharp_Szymon_Marcinkiewicz
{
    internal class Class3
    {
        static void Main(string[] args)
        {
            Person person = new Person("Miosz", "Ratkiewicz", 8888, "jeziorna", 420069888);
            CreditOwner creditOwner = new CreditOwner("Tobiarz", "Grabarczyk", 0000, "jeziorna", 0000);
            Bank bank = new Bank("Tobiarz", 0000, 0000, "jeziorna", 0000);

            Console.ReadKey();
        }
    }
}
