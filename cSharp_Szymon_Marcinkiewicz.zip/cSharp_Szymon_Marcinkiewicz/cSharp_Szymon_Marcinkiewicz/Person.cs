﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

    namespace cSharp_Szymon_Marcinkiewicz
{ 
        public class Person
        {
            private string name;
            private string surname;
            private int pesel;
            private string adres;
            private int phoneNumber;

            public Person(string name, string surname, int pesel, string adres, int phoneNumber)
            {
                this.name = name;
                this.surname = surname;
                this.pesel = pesel;
                this.adres = adres;
                this.phoneNumber = phoneNumber;

                

            }
            public string getName()
            {
                return name;
            }
            public string getSurname()
            {
                return surname;
            }
            public int getPesel()
            {
                return pesel;
            }
            public string getAdres()
            {
                return adres;
            }
            public int getPhoneNumber()
            {
                return phoneNumber;
            }
        }
}
